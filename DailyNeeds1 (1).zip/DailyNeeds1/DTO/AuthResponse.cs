﻿namespace DailyNeeds1.DTO
{
    public class AuthResponse
    {
        public string UserName { get; set; }
        public int RoleId { get; set; }
        public string Token { get; set; }
    }
}
