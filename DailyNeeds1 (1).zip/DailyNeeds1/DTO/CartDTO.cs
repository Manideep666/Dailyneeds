﻿namespace DailyNeeds1.DTO
{
    public class CartDTO
    {
        public int CartID { get; set; }
        public int UserID { get; set; }
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }
}
