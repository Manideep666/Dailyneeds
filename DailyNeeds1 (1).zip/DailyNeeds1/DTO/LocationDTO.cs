﻿namespace DailyNeeds1.DTO
{
    public class LocationDTO
{
    public int LocId { get; set; }
    public string LocName { get; set; }
    public int CityId { get; set; }
}
}