﻿namespace DailyNeeds1.DTO
{
    public class OfferDTO
    {
        public int OfferId { get; set; }
        public int ProductID { get; set; }
        public decimal OfferPercentage { get; set; }
    }
}
